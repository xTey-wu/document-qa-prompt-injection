# 正式实验复现包

使用 Python 3.9 或更新版本，在本目录运行 `python3 verify_reproduction.py` 复算论文补充结果。配置、数据结构和远程运行命令见[复现指南](REPRODUCTION.md)。
