# 文档问答提示注入评测包

本包包含 Faro 的 curl 接口联调脚本、原创合成样本与联调汇总。使用 Python 3.9 或更新版本，在本目录运行：

```sh
python3 experiment.py --smoke --split test
python3 experiment.py --dry-run --split test
```

第一条检查筛查、校验、评分及续跑规则，第二条列出持出集的计划请求量。样本按源文档划分为开发集与持出集，每题构造干净、注入和合法指令式三个版本。

远程运行时，在终端环境中设置服务基址 `LLM_BASE_URL`、模型标识 `LLM_MODEL` 和凭据 `LLM_API_KEY`，然后运行 `python3 experiment.py --run --split pilot --out runs/pilot --transport curl --timeout 60`。使用新目录记录不同模型或参数。同一目录续跑时，脚本跳过已成功请求。

`pilot_status.json` 记录 6 次联调请求中的 1 次成功返回及 5 次传输异常。论文正式结果位于正式复现包的 `faro-test/`。
